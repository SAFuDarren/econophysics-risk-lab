# Rebuilding the English research report

Run from this directory with a standard pdfLaTeX installation:

```
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The editable entry point is main.tex. Keep images/ and tables/ next to it. References are embedded in main.tex. Packages: fontenc,T1,lmodern,microtype,amsmath,amssymb,graphicx,booktabs,natbib,geometry,caption,fancyhdr,xcolor,array,float,hyperref. Vector scientific figures are copied unchanged from the respective study releases.
