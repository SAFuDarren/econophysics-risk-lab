# Rebuilding the research report

This archive contains the editable LaTeX entry point, source table fragments, and vector scientific figures. All references are embedded in main.tex.

Run from this directory with a standard LaTeX installation:

```
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The report uses pdfLaTeX, lmodern, microtype, amsmath, natbib, geometry, graphicx, caption, fancyhdr and hyperref. Preserve the images/ and tables/ directory names.
